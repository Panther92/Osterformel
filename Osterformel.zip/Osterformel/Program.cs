﻿using System;
using System.Globalization;


namespace Osterformel
{
    class Program
    {
        static void Main(string[] args)
        {

            //ToDo's
            //1. Begrenze die Berechnung von y innerhalb einer Spanne von 1583 (Beginn des gregorianischen Kalenders) bis 9999
            //2. Erlaube nur Integers als gültige Eingabe
            //3. Erlaube nur die Eingabe von vierstelligen Zahlen.
            

            System.Console.WriteLine("########################");
            System.Console.WriteLine("# Spencers Osterformel #"); // Grundlage https://de.wikipedia.org/wiki/Spencers_Osterformel
            System.Console.WriteLine("########################");
            System.Console.WriteLine("Sir Harold Spencer Jones (1890 – 1960)");
            System.Console.WriteLine("Ein kleines Programm geschrieben von Paul Volz");
            System.Console.WriteLine("");

            System.Console.WriteLine("Wann ist Ostern?");
            Console.WriteLine("Gib bitte eine Jahreszahl ein.");
            System.Console.WriteLine("");

            System.Console.WriteLine("Jahr:");
            int y = Int32.Parse(Console.ReadLine()); // Wartet auf Input einer Jahreszahl. Klappt komischerweise nicht im Debugger.
            System.Console.WriteLine("");

            

            if(y>=0)        // Beginne die Berechnung, wenn die eingegebene Zahl größer oder gleich 0 ist.
            {
            int a = y%19;
            int b = y/100;
            int c = y%100;
            int d = b/4;
            int e = b%4;
            int f = (b+8)/25;
            int g = (b-f+1)/3;
            int h = (19*a+b-d-g+15)%30;
            int i = c/4;
            int k = c%4;
            int l = (32+2*e+2*i-h-k)%7;
            int m = (a+11*h+22*l)/451;
            int n = (h+l-7*m+114)/31; // Monat; entspicht entweder 3 (März) oder 4 (April).
            int p = (h+l-7*m+114)%31; // p+1 entspicht dem berechneten Wochentag.
               
            System.Console.WriteLine("      |A|");
            System.Console.WriteLine("   .::| |::.");
            System.Console.WriteLine("  ::__| |__::");
            System.Console.WriteLine(" >____   ____<");
            System.Console.WriteLine("  ::  | |  ::");
            System.Console.WriteLine("   '::| |::'");
            System.Console.WriteLine("      | |");
            System.Console.WriteLine("      | |");
            System.Console.WriteLine("      |Ω|");
            System.Console.WriteLine("");

            switch(n)
            {
                case 3:
                System.Console.WriteLine("Im Jahr "+y+" war/ist Ostersonntag am "+(p+1)+". März.");
                break;

                case 4:
                System.Console.WriteLine("Im Jahr "+y+" war/ist Ostersonntag am "+(p+1)+". April.");
                break;
            }

            System.Console.ReadLine();
            }

            else // Für die Scherzkekse unter uns
            {
                System.Console.WriteLine("");
                System.Console.WriteLine("┌П┐(▀̿Ĺ̯▀̿) ");
                System.Console.WriteLine("");

                System.Console.WriteLine("Deine Mudda ist so christlich, sie feierte Ostern schon vor Christi Geburt!");
                System.Console.ReadLine();
            }
        }
    }
}
